﻿using CoinJarRESTApi.Models;
using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace CoinJarRESTApi.Controllers
{
    [RoutePrefix("api/coin")]
    public class CoinController : ApiController
    {
        [HttpPost]
        public HttpResponseMessage AddCoin(HttpRequestMessage request,Coins coins)
        {                    
            try
            {
                CoinJar.GetInstance().AddCoin(coins);
            }
            catch (Exception ex)
            {
                var response = new HttpResponseMessage(HttpStatusCode.NotModified);
                response.ReasonPhrase = ex.Message;
                return response;
            }

            return request.CreateResponse(HttpStatusCode.OK, CoinJar.GetInstance().CoinLists);
        }

        [HttpGet]
        public decimal GetTotalAmount()
        {
            return CoinJar.GetInstance().GetTotalAmount();
        }

        [HttpDelete]
        [Route("reset")]
        public List<Coins> Reset()
        {
            CoinJar.GetInstance().Reset();
            return CoinJar.GetInstance().CoinLists;
        }

    }
}
