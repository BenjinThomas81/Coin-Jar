﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CoinJarRESTApi.Models
{

    public interface ICoin
    {
        //US Coinage in cents (Not $)
        decimal Amount { get; set; }
        decimal Volume { get; set; }
    }
    public interface ICoinJar
    {
        void AddCoin(ICoin coin);
        decimal GetTotalAmount();
        void Reset();
    }

    public class Coins : ICoin
    {
        public decimal Amount { get; set; }
        public decimal Volume { get; set; }
    }

    public class CoinJar : ICoinJar
    {
        public List<Coins> CoinLists;
        static CoinJar coinJar = null;

        private static readonly decimal MaxFluidOunces = (decimal)1182.9411824;
        /*
         *Volume in gram.
         * Below is the link that i used to determine the volume of each currency.
         * https://en.wikipedia.org/wiki/Coins_of_the_United_States_dollar#Current_coinage
         * 1. Based on the Volume of each currency type, if the user passes a volume that doesn't match the one's specified below, added validation
         *    to throw an exception
         * 2. If the sum of the total volumes exceed the MxFluidOunces (i.e. 40 Ounces), added validation to raise an error.
        */
        public static readonly decimal centVolumeValue = (decimal)2.5;
        public static readonly decimal nickelVolumeValue = (decimal)5.0;
        public static readonly decimal dimVolumeValue = (decimal)2.268;
        public static readonly decimal quarterVolumeValue = (decimal)5.67;
        public static readonly decimal halfVolumeValue = (decimal)11.34;
        public static readonly decimal largeVolumeValue = (decimal)22.68;

        readonly decimal[] coinVolumes = new decimal[] { centVolumeValue, nickelVolumeValue, dimVolumeValue, quarterVolumeValue, halfVolumeValue, largeVolumeValue };


        public CoinJar()
        {
            if (CoinLists == null)
            {
                CoinLists = new List<Coins>();
            }            
        }

        public static CoinJar GetInstance()
        {
            /*
             * Creating the instance of the object if Null.
            */
            if (coinJar == null)
            {
                coinJar = new CoinJar();
                return coinJar;
            }
            else
            {
                return coinJar;
            }
        }

        public void AddCoin(ICoin coin)
        {
            //Validating the coin
            ValidateCoin(coin);

            Coins colCoins = new Coins();
            colCoins.Amount = coin.Amount;
            colCoins.Volume = coin.Volume;
            CoinLists.Add(colCoins);

        }

        public decimal GetTotalAmount()
        {
            /*
             * Calculating the total based on the amount passed.
            */ 
            decimal totalAmount = 0;
            totalAmount = CoinLists.AsEnumerable().Sum(a => a.Amount);

            return totalAmount;
        }

        public void Reset()
        {
            CoinLists.Clear();
        }


        /*
         * Creating seperate method for validation purpose
        */
        private void ValidateCoin(ICoin coin)
        {
            /*
             *  Fl oz to gram
             *  1 fluid Ounces = 29.57352956g
             *  40 fluid Ounces = 29.57352956 * 40 = 1182.9411824g
             *  Cent    : 2.5g
             *  Nickel  : 5g
             *  Dim     : 2.268g
             *  Quarter : 5.67g
             *  Half    : 11.34g
             *  Large   : 22.68g
            */
            decimal totalVolume = 0;
            foreach (var coinList in CoinLists)
            {
                totalVolume = totalVolume + (coinList.Volume * coinList.Amount);
            }
            totalVolume = totalVolume + (coin.Volume * coin.Amount);

            /*
                 * Checking if the Latest US coinage is been passed,  based on the Volume passed.
            */
            if (!new[] { centVolumeValue, nickelVolumeValue, dimVolumeValue, quarterVolumeValue, halfVolumeValue, largeVolumeValue }.Any(x => x == coin.Volume))
            {
                throw new ArgumentException("Invalid coin volume");
            }

            /*
             * Checking if the Amount passed matches the type of coin usage
            */
            if (coin.Volume == nickelVolumeValue)
            {
                /*
                 *For example if the user specified the following
                 * {Amount = 143, Volume = 2.5g}
                 * 2.5 g = 5 cent
                 * Checking if the amount specified is all 5 cents
                 * 143 % 2.5 = 0.5, which is not zero i.e. the amount includes other coinage type.
                */
                if (coin.Amount % 5 != 0)
                {
                    throw new ArgumentException("Amount specified does not match the Coinage type of 5 cent");
                }
            }

            if (coin.Volume == dimVolumeValue)
            {
                /*
                 *For example if the user specified the following
                 * {Amount = 143, Volume = 2.5g}
                 * 2.268 g = 10 cent
                 * Checking if the amount specified is all 5 cents
                 * 143 % 10 = 3, which is not zero i.e. the amount includes other coinage type.
                */
                if (coin.Amount % 10 != 0)
                {
                    throw new ArgumentException("Amount specified does not match the Coinage type of 10 cent");
                }
            }

            if (coin.Volume == quarterVolumeValue)
            {
                /*
                 *For example if the user specified the following
                 * {Amount = 143, Volume = 2.5g}
                 * 5.67 g = 20 cent
                 * Checking if the amount specified is all 5 cents
                 * 143 % 20 = 3, which is not zero i.e. the amount includes other coinage type.
                */
                if (coin.Amount % 20 != 0)
                {
                    throw new ArgumentException("Amount specified does not match the Coinage type of 20 cent");
                }
            }

            if (coin.Volume == halfVolumeValue)
            {
                /*
                 *For example if the user specified the following
                 * {Amount = 143, Volume = 2.5g}
                 * 11.34 g = 50 cent
                 * Checking if the amount specified is all 5 cents
                 * 143 % 50 = 43, which is not zero i.e. the amount includes other coinage type.
                */
                if (coin.Amount % 50 != 0)
                {
                    throw new ArgumentException("Amount specified does not match the Coinage type of 50 cent");
                }
            }

            /*
                * The maximum coin jar Volumn is 42 fluid Ounces. 
                * Validating before adding, checking to make  sure that the Coin Jar hasn't exceeded the volume of 40 fluid Ounces.      
            */
            if (!(totalVolume < MaxFluidOunces))
            {
                throw new InvalidOperationException("Coin jar is Full!");
            }
        }
    }
}