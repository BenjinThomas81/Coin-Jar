﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace CoinJarRESTApi.Tests.Controllers
{
    [TestClass]
    public class CoinJarTester
    {
        //CoinController controller = new CoinController();
        private static readonly HttpClient client = new HttpClient();

        public CoinJarTester()
        {
            client.BaseAddress = new System.Uri("http://localhost:8080/");
        }

        [TestMethod]
        public async Task TestAddCoinAsync()
        {
            //invalid coin volume
            var invalidCoin = new
            {
                Amount = 2,
                Volume = 2
            };

            //valid coin
            var validCoin = new
            {
                Amount = 2,
                Volume = 2.5
            };

            var response = await client.PostAsync("api/coin", new StringContent(JsonConvert.SerializeObject(invalidCoin), Encoding.UTF8, "application/json"));
            Assert.AreEqual(System.Net.HttpStatusCode.NotModified, response.StatusCode);

            var response2 = await client.PostAsync("api/coin", new StringContent(JsonConvert.SerializeObject(validCoin), Encoding.UTF8, "application/json"));
            Assert.AreEqual(System.Net.HttpStatusCode.OK, response2.StatusCode);
        }
    }
}
